import React from "react";
import './store.css';
import { Component } from "react";
import StoreService from "./StoreService";


class StoreComponent extends React.Component{

    constructor(props){
        super(props);
        this.state={stores:[]}
    }


    componentDidMount(){
        StoreService.getAllStores()
        .then(res=>this.setState({stores:res.data}))
    }


    render(){
        return(

        <div class="card-group">
            <table>
                <div className="card">
                  <thead>
                    <tr>
                    <th>Store Name</th> 
                    <th>Store Phone Number</th>
                    <th>Store Email</th>
                    <th>Store Address</th>
                    </tr>
                   </thead>
                 <tbody>
                 {this.state.stores.map( store =>  
                    <tr>
                    <td>{store.name}</td>
                    <td>{store.phoneNumber}</td>
                    <td>{store.email}</td>
                    <td>{store.address}</td>
                    </tr>
                     )}
                  </tbody>
                </div>   
            </table>
        </div>
        )
    }

}

export default StoreComponent