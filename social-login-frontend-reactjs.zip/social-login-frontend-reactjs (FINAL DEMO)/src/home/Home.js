import React, { Component } from 'react';
import './Home.css';
import { Link } from 'react-router-dom';
import homepage from '../img/homepage.jpg';

class Home extends Component {
    render() {
        return (
            <div className="home-container">
                <div className="title-wrapper">
                    <h1 className="home-title">"Discover Your Neighborhood Like Never Before"</h1>
                    <div className="subtitle-container">
                        <h4>Explore your community with our intuitive application.</h4>
                    </div>
                    <Link to="/signup" className="link-style">Register now</Link>
                </div>
                    <div className="container"> 
                        <img src={homepage} alt="KYN Online Store"></img>
                    </div>
            </div>
        )
    }
}

export default Home;