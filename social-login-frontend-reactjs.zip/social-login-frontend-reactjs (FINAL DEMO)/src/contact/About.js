import React, { Component } from 'react';
import './contact.css';
import compthree from '../img/compthree.jpg';

class AboutComp extends Component {
    render() {
        return (
            <div className="about-container">
                <h1>About Us</h1>
                <div className="about-img"> 
                        <img src={compthree} alt="About Us"></img>
                </div>
                <div className="about-content">
                <p>We are a team of passionate developers dedicated to creating innovative solutions for our users.</p>
                <p>At our core, we believe in the power of technology to transform lives and communities. With this belief driving us, we strive to develop products that not only meet the needs of our users but also exceed their expectations.</p>
                <p>Our mission is to empower communities and enhance connectivity through technology. Whether it's through our mobile applications, web platforms, or other digital solutions, we aim to make a positive impact on the world around us.</p>
                <p>As a team, we are committed to continuous improvement and growth. We value collaboration, creativity, and a customer-centric approach in everything we do.</p>
                <p>Thank you for joining us on this journey. Together, we can build a brighter future through innovation and technology.</p>
                </div>
            </div>
        );
    }
}

export default AboutComp;