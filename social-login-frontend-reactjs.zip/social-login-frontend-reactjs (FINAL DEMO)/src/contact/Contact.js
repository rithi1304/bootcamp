import React, { Component } from 'react';
import './contact.css';

class ContactComp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name: '',
            email: '',
            message: ''
        };
    }

    handleInputChange = (event) => {
        const { name, value } = event.target;
        this.setState({ [name]: value });
    }

    handleSubmit = (event) => {
        event.preventDefault();
        // Implement your logic to handle form submission here
        console.log('Form submitted:', this.state);
    }

    render() {
        const { name, email, message } = this.state;
        return (
            <div className="contact-container">
                <h1>Contact Us</h1>
                <p>You can contact us via the following methods:</p>
                <ul>
                    <li>Email: <span className='con'>info@KYN.com</span></li>
                    <li>Phone: <span className='con'>+1 (123) 456-7890</span></li>
                    <li>Address: <span className='con'>123 Main St, City, Country</span></li>
                </ul>
                    <form>
                        <div className="form-group">
                            <label htmlFor="name">Name</label>
                            <input type="text" id="name" name="name" required/>
                        </div>
                        <div className="form-group">
                            <label htmlFor="email">Email</label>
                            <input type="email" id="email" name="email" required/>
                        </div>
                        <div className="form-group">
                            <label htmlFor="message">Message</label>
                            <textarea id="message" name="message" required></textarea>
                        </div>
                        <button type="submit">Submit</button>
                </form>
            </div>
        );
    }
}

export default ContactComp;
