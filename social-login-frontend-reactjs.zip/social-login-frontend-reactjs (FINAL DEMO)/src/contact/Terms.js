import React, { Component } from 'react';
import './contact.css';

class term extends Component {
    render() {
    return (
        <div className="terms-container">
            <h1 className='term-title'>Terms and Conditions</h1>
            <p>Welcome to the Know Your Neighborhood (KYN) application. By accessing or using our platform, you agree to comply with and be bound by the following terms and conditions:</p>
            <h2>1. Acceptance of Terms</h2>
            <p>By accessing or using the KYN application, you agree to be bound by these terms and conditions, which constitute a legally binding agreement between you and KYN.</p>
            <h2>2. User Registration</h2>
            <p>In order to access certain features of the KYN application, you may be required to register for an account. You agree to provide accurate and complete information during the registration process and to update such information to keep it accurate and current.</p>
            <h2>3. Social Login</h2>
            <p>By using social login functionality on the KYN application, you authorize us to access certain information from your social media accounts, including but not limited to your name and email address. We will use this information in accordance with our Privacy Policy.</p>
            <h2>4. User Conduct</h2>
            <p>You agree to use the KYN application only for lawful purposes and in accordance with these terms and conditions. You are prohibited from engaging in any conduct that may violate any applicable laws or regulations.</p>
            <h2>5. Intellectual Property</h2>
            <p>All content and materials available on the KYN application, including but not limited to text, graphics, logos, images, and software, are the property of KYN or its licensors and are protected by intellectual property laws.</p>
            <h2>6. Limitation of Liability</h2>
            <p>Under no circumstances shall KYN or its affiliates be liable for any direct, indirect, incidental, consequential, special, or exemplary damages arising out of or in connection with your use of the KYN application.</p>
            <h2>7. Governing Law</h2>
            <p>These terms and conditions shall be governed by and construed in accordance with the laws of india, without regard to its conflict of law provisions.</p>
            <h2>8. Changes to Terms</h2>
            <p>KYN reserves the right to modify or revise these terms and conditions at any time, and your continued use of the KYN application following any such changes shall constitute your acceptance of such changes.</p>
            <h2>9. Contact Us</h2>
            <p>If you have any questions about these terms and conditions, please contact us at <span className='t-mail'>info@KYN.com</span>.</p>
        </div>
    );
}

}
export default term;