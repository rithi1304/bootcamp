import React from 'react';
import { Component } from 'react';
import './AppFooter.css';

class FooterComp extends Component {
    render() {
        return (
            <footer className="app-footer">
                <hr></hr>
                <div className="container">
                    <div className="foot-options">
                        <nav className="foot-nav">
                                    <ul>
                                        <li>
                                            <a href="About">about us</a>
                                        </li>
                                        <li>
                                            <a href="Contact">contact us</a>
                                        </li>
                                        <li>
                                            <a href="Priv">privacy policy</a>
                                        </li>
                                        <li>
                                            <a href="Terms">terms & conditions</a>
                                        </li>
                                    </ul>
                        </nav>
                    </div>
                </div>
            </footer>
        )
    }
}

export default FooterComp;