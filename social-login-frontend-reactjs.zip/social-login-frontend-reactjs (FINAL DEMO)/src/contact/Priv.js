import React, { Component } from 'react';
import './contact.css';

class PrivComp extends Component {
    render() {
        return (
            <div className="priv-container">
            <h1 className='priv-title'>Privacy Policy</h1>
            <p>Welcome to the Know Your Neighborhood (KYN) application. This Privacy Policy outlines how we collect, use, and protect your personal information when you use our services.</p>
            
            <h2>Information We Collect</h2>
            <p>We collect information you provide directly to us, such as when you register for an account, use our services, or contact us for support. This information may include your name, email address, and any other information you choose to provide.</p>

            <h2>How We Use Your Information</h2>
            <p>We may use the information we collect to:</p>
            <ul>
                <li>Provide, maintain, and improve our services</li>
                <li>Respond to your inquiries and support requests</li>
                <li>Communicate with you about our services, promotions, and updates</li>
                <li>Personalize and optimize your user experience</li>
            </ul>

            <h2>Information Sharing and Disclosure</h2>
            <p>We do not sell, trade, or otherwise transfer your personal information to third parties without your consent, except as described in this Privacy Policy or as required by law.</p>

            <h2>Security</h2>
            <p>We take reasonable measures to protect your personal information from unauthorized access, use, alteration, or destruction. However, please be aware that no method of transmission over the internet or electronic storage is 100% secure.</p>

            <h2>Changes to This Privacy Policy</h2>
            <p>We reserve the right to update or modify this Privacy Policy at any time. Any changes will be effective immediately upon posting on this page. We encourage you to review this Privacy Policy periodically for any updates.</p>

            <h2>Contact Us</h2>
            <p>If you have any questions about this Privacy Policy, please contact us at <span className='p-mail'>info@KYN.com</span>.</p>
        </div>
        );
    }
}

export default PrivComp;